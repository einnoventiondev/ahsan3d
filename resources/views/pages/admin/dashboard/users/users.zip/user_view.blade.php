@extends('layouts.admin.app')
@section('content')
<div class="content-main">
    <h3>قائمة المستخدمين</h3>
    <div class="breadcrumb-main">
        <ol class="breadcrumb">
            <li><a href="{{route('home')}}">الصفحة الرئيسية</a></li>

            <li><a href="{{ route('user.list') }}">قائمة المستخدمين</a></li>
        </ol>
    </div>
    <div class="container-fluid p-0">
        <div class="row">
            <div class="col-sm-12">
                <div class="card medical-card">
                    <div class="card-body p-0">
                        <form class="row" action="" method="">
                            <div class="mb-3 col-md-6">
                                <label for="exampleFormControlInput1" class="form-label">لقب</label>
                                <input readonly="" type="text" class="form-control" id="exampleFormControlInput1" value="name">
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="exampleFormControlInput1" class="form-label">البريد الإلكتروني</label>
                                <input readonly="" type="email" class="form-control" id="exampleFormControlInput1" value="email">
                            </div>

                            <div class="mb-3 col-md-6">
                                <label for="exampleFormControlInput1" class="form-label">الهاتف</label>
                                <input readonly="" type="number" class="form-control" id="exampleFormControlInput1" value="phone">
                            </div>
                        </form>

                        <div class="table-responsive">
                            <h3 class="mt-5">الطلبات</h3>
                            <table class="display table table-borderless  user-table mt-4" style="width:100%">
                                <thead>
                                    <th class="border-btm-blue">طبي</th>
                                    <th class="border-btm-blue">عام</th>
                                    <th class="border-btm-blue">المصممين</th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>12</td>
                                        <td>231</td>
                                        <td>1231</td>
                                    </tr>
                                    <tr>
                                        <td>12</td>
                                        <td>231</td>
                                        <td>1231</td>
                                    </tr>
                                    <tr>
                                        <td>12</td>
                                        <td>231</td>
                                        <td>1231</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
