@extends('layouts.admin.app')
@section('content')
<div class="content-main">
    <h3> قائمة المصممين </h3>
    <div class="breadcrumb-main">
        <ol class="breadcrumb">
            <li><a href="{{route('home')}}">الصفحة الرئيسية</a></li>

            <li><a href="{{ route('user.list') }}">قائمة المصممين</a></li>
        </ol>
    </div>
    <div class="container-fluid p-0">
        <div class="row">
            <div class="col-sm-12">
                <div class="card medical-card">
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="display table table-borderless  user-table mt-4" style="width:100%">
                                <thead>
                                    <th class="border-btm-blue">لقب</th>
                                    <th class="border-btm-blue">البريد الإلكتروني</th>
                                    <th class="border-btm-blue">رقم الهاتف</th>
                                    <th class="border-btm-blue">3d تكنولوجيا</th>
                                    <th class="border-btm-blue">طلب</th>
                                    <th class="border-btm-blue">الطلب</th>

                                </thead>
                                <tbody>
                                    <tr>
                                        <td>name</td>
                                        <td>email</td>
                                        <td>phone</td>
                                        <td>3d technology</td>
                                        <td>application</td>
                                        <td>orders</td>

                                    </tr>
                                    <tr>
                                        <td>name</td>
                                        <td>email</td>
                                        <td>phone</td>
                                        <td>3d technology</td>
                                        <td>application</td>
                                        <td>orders</td>

                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
